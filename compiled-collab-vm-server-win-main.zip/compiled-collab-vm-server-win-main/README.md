# compiled-collab-vm-server-win
CollabVM pre-compiled for Windows.

# What it contains
* CollabVM 1.2.10
* Themes

# How to set up
* Download and run.